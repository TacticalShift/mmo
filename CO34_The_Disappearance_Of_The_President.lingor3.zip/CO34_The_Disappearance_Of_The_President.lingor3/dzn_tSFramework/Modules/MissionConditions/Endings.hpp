class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Президент успешно спасен";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "НЕЕЕЕЕЕТ!";
        description = "Президент умер";
    };
};
