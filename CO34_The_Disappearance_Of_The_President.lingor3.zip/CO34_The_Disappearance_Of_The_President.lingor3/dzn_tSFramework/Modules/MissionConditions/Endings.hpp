class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Президент успешно спасен";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Провал!";
        description = "Все умерли";
    };
	class FAIL
    {
        title = "Задание провалено";
        subtitle = "Провал!";
        description = "Президент умер";
    };
};
