class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено полностью";
        subtitle = "Успех!";
        description = "Задачи выполнены";
    };
    class PART
    {
        title = "Задание выполнено частично";
        subtitle = "Успех!";
        description = "Мы потеряли МТЛБ";
    };                     
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
