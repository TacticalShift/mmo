class CfgDebriefing
{
	class FULL_WIN
	{
		title = "Миссия выполнена";
		subtitle = "Восхитительный успех!";
		description = "Задачи выполнена, мины разминированы";
	};
	class WIN
	{
		title = "Миссия выполнена";
		subtitle = "Успех!";
		description = "Задача выполнена.";
	};
	class FAIL
	{
		title = "Миссия провалена";
		subtitle = "Восхитительный провал";
		description = "";
	};
	class WIPED
	{
		title = "Миссия провалена";
		subtitle = "Все погибли";
		description = "Такие дела...";
	};
};