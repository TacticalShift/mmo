class CfgDebriefing
{  
    class SERBIA
    {
        title = "Победа";
        subtitle = "Успех!";
        description = "Сербия успешно захватила КПП";
    };                  
    class MONTENEGRO
    {
        title = "Победа";
        subtitle = "Успех!";
        description = "Черногория успешно захватила КПП";
    };
};
