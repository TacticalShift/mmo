class CfgDebriefing
{  
    class FULL_WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };  
    class WIN_TRG1
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    }; 
    class WIN_TRG2
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };  	
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
