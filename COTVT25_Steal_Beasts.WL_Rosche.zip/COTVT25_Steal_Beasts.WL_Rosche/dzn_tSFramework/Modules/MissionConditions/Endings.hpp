class CfgDebriefing
{
	class BLUE_FULL_WIN
	{
		title = "Полная победа BLUEFOR";
		subtitle = "Восхитительный успех!";
		description = "Задачи выполнены с полной победой синих";
	};
	class BLUE_WIN
	{
		title = "Победа синих";
		subtitle = "Основные задачи выполнены";
		description = "Команде BLUEFOR удалось выполнить основные задачи";
	};
	class RED_FULL_WIN
	{
		title = "Полная победа красных";
		subtitle = "Восхитительный успех!";
		description = "Задачи выполнены с полной победой красных";
	};
	class RED_WIN
	{
		title = "Победа красных";
		subtitle = "Основные задачи выполнены";
		description = "OPFOR удалось задержать противника";
	};
	class DRAW
	{
		title = "Ничья";
		subtitle = "Обе стороны не достигли целей";
		description = "";
	};
	class WIPED
	{
		title = "Миссия провалена";
		subtitle = "Все погибли";
		description = "Такие дела...";
	};
};