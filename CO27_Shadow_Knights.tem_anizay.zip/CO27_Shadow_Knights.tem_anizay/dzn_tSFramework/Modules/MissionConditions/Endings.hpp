class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Главнокомандующий ИГИЛ захвачен и доставлен на базу.";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
