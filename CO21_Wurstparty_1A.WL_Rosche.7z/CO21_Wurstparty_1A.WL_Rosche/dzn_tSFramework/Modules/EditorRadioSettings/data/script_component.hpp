#include "..\..\script_macro.hpp"

#define COMPONENT EditorRadioSettings

#define GAMELOGIC_FLAG Q(tSF_ERS_Config)
