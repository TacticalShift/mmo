#include "..\..\script_macro.hpp"

#define COMPONENT tSAdminTools
