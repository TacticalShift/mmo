[
	"Guards1_dzn" /* Zone Name */
	,"WEST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
	/* (OPTIONAL) Activation condition */
	,{ true }
	/* Extras */ 
	,[
		["providesSupport", false],
		["requestsSupport", true]
	]
]
, [
	"Guards2_dzn" /* Zone Name */
	,"WEST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
	/* (OPTIONAL) Activation condition */
	,{ true }
	/* Extras */ 
	,[
		["providesSupport", false],
		["requestsSupport", true]
	]
]
, [
	"Guards3_dzn" /* Zone Name */
	,"WEST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
	/* (OPTIONAL) Activation condition */
	,{ true }
	/* Extras */ 
	,[
		["providesSupport", false],
		["requestsSupport", true]
	]
]
, [
	"Guards4_dzn" /* Zone Name */
	,"WEST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_pistol"]
				,["B_Soldier_F", ["entrenched"], "kit_spa_civguard_r"]
				,["TCGM_RollUp_B_MTP_Soldier_AR", ["entrenched"], "kit_spa_civguard_fem_r"]
				,["TCGM_RollUp_B_MTP_Soldier_AR", ["entrenched"], "kit_spa_civguard_fem_pistol"]
				,["TCGM_RollUp_B_MTP_Soldier_AR", ["entrenched"], "kit_spa_civguard_fem_pistol"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
]
, [
	"Guards5_dzn" /* Zone Name */
	,"WEST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["TCGM_RollUp_B_MTP_Soldier_AR", ["entrenched"], "kit_spa_civguard_fem_r"]
				,["TCGM_RollUp_B_MTP_Soldier_AR", ["entrenched"], "kit_spa_civguard_fem_r"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
]
, [
	"Church_dzn" /* Zone Name */
	,"EAST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
]
, [
	"Hospital_dzn" /* Zone Name */
	,"EAST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
]
, [
	"Office_dzn" /* Zone Name */
	,"EAST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_mm"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_mm"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["entrenched"], "kit_slave_cartel_aux"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","SAFE","YELLOW","WEDGE"]
]
, [
	"General_dzn" /* Zone Name */
	,"EAST",true, /* Side, is Active */ [],[]
	/* Groups: */
	,[
		[
			1, /* Groups quantity */
			/* Units */
			[
				["O_Soldier_F", ["indoors"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_random"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
				,["O_Soldier_F", ["indoors"], "kit_slave_cartel_aux"]
			]
		]
		,[
			4, /* Groups quantity */
			/* Units */
			[
				["O_Soldier_F", [], "kit_slave_cartel_aux"]
				,["O_Soldier_F", [], "kit_slave_cartel_aux"]
			]
		]
	]
	/* Behavior: Speed, Behavior, Combat mode, Formation */
	,["LIMITED","AWARE","YELLOW","WEDGE"]
]