// ***********************************// ***********************************
// Gear Kits
// ***********************************
// ******** GEAR CLASSES **********
//
//	Maptools		"ACE_MapTools"	["ACE_MapTools",1]
//	Binocular		"Binocular"	["Binocular",1]
//
// 	Map			"ItemMap"
//	Compass			"ItemCompass"
//	Watch			"ItemWatch"
//	Personal Radio		"ItemRadio"
//
// ******* KIT NAMES FORMAT ********
//  Kit names format:		kit_FACTION_ROLE
//	Platoon Leader / Командир Взвода	->	kit_ussf_pl
//	Squad Leader / Командир отделения	->	kit_ussf_sl
//	Section Leader				->	kit_ussf_sl
//	2IC					->	kit_ussf_2ic
//	Fireteam Leader				->	kit_ussf_ftl
//	Automatic Rifleman			->	kit_ussf_ar
//	Grenadier / Стрелок (ГП)		->	kit_ussf_gr
//	Rifleman / Стрелок			->	kit_ussf_r
//	Экипаж					->	kit_ussf_crew
//	Пулеметчик				->	kit_ussf_mg
//	Стрелок-Гранатометчик			->	kit_ussf_at
//	Стрелок, помощник гранатометчика	->	kit_ussf_aat
//	Старший стрелок				->	kit_ussf_ar / kit_ussf_ss
//	Снайпер					->	kit_ussf_mm
// ****************
//
// ******** USEFUL MACROSES *******
// Maros for Empty weapon
#define EMPTYKIT	[["","","","",""],["","","","",""],["","","","",""],["","","","",""],[],[["",0],["",0],["",0],["",0],["",0],["",0],["",0],["",0],["",0]],[["",0],["",0],["",0],["",0],["",0],["",0]],[]]
// Macros for Empty weapon
#define EMPTYWEAPON	"","",["","","",""]
// Macros for the list of items to be chosen randomly
#define RANDOM_ITEM	["H_HelmetB_grass","H_HelmetB"]
// Macros to give the item only if daytime is in given inerval (e.g. to give NVGoggles only at night)
#define NIGHT_ITEM(X)	if (daytime < 9 || daytime > 18) then { X } else { "" }

// ******** ASSIGNED and UNIFORM ITEMS MACRO ********
#define NVG_NIGHT_ITEM		if (daytime < 9 || daytime > 18) then { "NVGoggles_OPFOR" } else { "" }
#define BINOCULAR_ITEM		"Binocular"

#define ASSIGNED_ITEMS		"ItemMap","ItemCompass","ItemWatch","ItemRadio", NVG_NIGHT_ITEM
#define ASSIGNED_ITEMS_L	"ItemMap","ItemCompass","ItemWatch","ItemRadio", NVG_NIGHT_ITEM, BINOCULAR_ITEM

#define UNIFORM_ITEMS		["ACE_fieldDressing",5],["ACE_packingBandage",5],["ACE_elasticBandage",5],["ACE_tourniquet",2],["ACE_morphine",2],["ACE_epinephrine",2],["ACE_quikclot",5],["ACE_CableTie",2],["ACE_Flashlight_XL50",1],["ACE_EarPlugs",1]
#define UNIFORM_ITEMS_L		["ACE_fieldDressing",5],["ACE_packingBandage",5],["ACE_elasticBandage",5],["ACE_tourniquet",2],["ACE_morphine",2],["ACE_epinephrine",2],["ACE_quikclot",5],["ACE_CableTie",2],["ACE_Flashlight_XL50",1],["ACE_EarPlugs",1],["ACE_MapTools",1]

#define PMC_UNIFORMS	["CUP_I_B_PARA_Unit_1","CUP_I_B_PARA_Unit_1","CUP_I_B_PARA_Unit_1","CUP_I_B_PARA_Unit_1","CUP_I_B_PARA_Unit_10","CUP_I_B_PARA_Unit_10","CUP_I_B_PARA_Unit_10","CUP_I_B_PARA_Unit_10","CUP_I_B_PARA_Unit_11","CUP_I_B_PARA_Unit_13","CUP_I_B_PARA_Unit_15","CUP_I_B_PARA_Unit_2","CUP_I_B_PARA_Unit_3","CUP_I_B_PARA_Unit_4","CUP_I_B_PARA_Unit_5","CUP_I_B_PARA_Unit_6","CUP_I_B_PARA_Unit_7","CUP_I_B_PARA_Unit_8"]
// ****************


kit_spa_ezapac_ftl = [
    ["<EQUIPEMENT       >> ","GEN_Olive_uniform_male","JCA_V_CarrierRigKBT_01_combat_olive_F","","JCA_H_HelmetHBK_chops_olive_F","rhsusf_shemagh2_gogg_grn"],
    ["<PRIMARY WEAPON   >> ","CUP_arifle_G36CA3_afg_wdl","CUP_30Rnd_556x45_G36",["","","CUP_optic_Elcan_SpecterDR_KF_RMR_od_PIP",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS_L],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS_L]],
    ["<VEST ITEMS       >> ",[["PRIMARY MAG",10],["rhs_mag_m67",2],["rhs_mag_an_m8hc",2]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Fireteam Leader"],
    ["<TAGS >> ","leader"]
] call dzn_fnc_gear_make;

kit_spa_ezapac_gr = [
    ["<EQUIPEMENT       >> ","GEN_Olive_uniform_male","JCA_V_CarrierRigKBT_01_combat_olive_F","B_AssaultPack_rgr","JCA_H_HelmetHBK_chops_olive_F","rhsusf_shemagh2_gogg_grn"],
    ["<PRIMARY WEAPON   >> ","CUP_arifle_G36K_RIS_AG36_wdl","CUP_30Rnd_556x45_G36",["","","CUP_optic_Elcan_SpecterDR_KF_RMR_od",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["rhs_mag_m67",2],["rhs_mag_an_m8hc",2],["PRIMARY MAG",10],["CUP_1Rnd_HE_M203",3]]],
    ["<BACKPACK ITEMS   >> ",[["CUP_1Rnd_HE_M203",7],["rhs_mag_m576",5],["1Rnd_Smoke_Grenade_shell",3],["rhs_mag_m4009",10]]],
    ["<DESC >> ","Grenadier"]
] call dzn_fnc_gear_make;

kit_spa_ezapac_sttp = [
    ["<EQUIPEMENT       >> ","GEN_Olive_uniform_male","JCA_V_CarrierRigKBT_01_combat_olive_F","B_AssaultPack_khk","JCA_H_HelmetHBK_chops_olive_F","rhsusf_shemagh2_gogg_grn"],
    ["<PRIMARY WEAPON   >> ","KA_UMP9","KA_30Rnd_9x19_FMJ_Mag",["","","CUP_optic_AC11704_Black",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["rhs_mag_m67",2],["rhs_mag_an_m8hc",2],["PRIMARY MAG",5],["KA_30Rnd_9x19_JHP_Mag",5]]],
    ["<BACKPACK ITEMS   >> ",[["rhs_mag_mk3a2",2],["rhs_mag_mk84",2],["ACE_CTS9",3],["rhs_mag_m67",4],["PRIMARY MAG",2],["KA_30Rnd_9x19_JHP_Mag",2],["CUP_200Rnd_TE1_Red_Tracer_556x45_M249",1]]]
] call dzn_fnc_gear_make;

kit_spa_ezapac_sl = [
    ["<EQUIPEMENT       >> ","GEN_Olive_uniform_male","JCA_V_CarrierRigKBT_01_combat_olive_F","TFAR_anprc155","JCA_H_HelmetHBK_chops_olive_F","rhsusf_shemagh2_gogg_grn"],
    ["<PRIMARY WEAPON   >> ","CUP_arifle_G36CA3_afg_wdl","CUP_30Rnd_556x45_G36",["","","CUP_optic_Elcan_SpecterDR_KF_RMR_od_PIP",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS_L],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS_L]],
    ["<VEST ITEMS       >> ",[["PRIMARY MAG",10],["rhs_mag_m67",2],["rhs_mag_an_m8hc",2]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Squad Leader"],
    ["<TAGS >> ","leader","PL_NET"]
] call dzn_fnc_gear_make;

kit_spa_ezapac_pilot = [
    ["<EQUIPEMENT       >> ","GEN_Olive_uniform_male","JCA_V_CarrierRigKBT_01_combat_olive_F","TFAR_anprc155","JCA_H_balaclava_01_headset_glasses_olive_F","rhsusf_shemagh2_gogg_grn"],
    ["<PRIMARY WEAPON   >> ","CUP_smg_p90_olive","50Rnd_570x28_SMG_03",["","","CUP_optic_AC11704_Black",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS_L],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS_L]],
    ["<VEST ITEMS       >> ",[]],
    ["<BACKPACK ITEMS   >> ",[]]
] call dzn_fnc_gear_make;

kit_spa_ezapac_pl = [
    ["<EQUIPEMENT       >> ","GEN_Olive_uniform_male","JCA_V_CarrierRigKBT_01_combat_olive_F","TFAR_anprc155","JCA_H_Beret_01_headset_olive_F","rhsusf_shemagh_gogg_grn"],
    ["<PRIMARY WEAPON   >> ","CUP_arifle_G36CA3_afg_wdl","CUP_30Rnd_556x45_G36",["","","CUP_optic_Elcan_SpecterDR_KF_RMR_od",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS_L],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS_L]],
    ["<VEST ITEMS       >> ",[["PRIMARY MAG",10],["rhs_mag_m67",2],["rhs_mag_an_m8hc",2]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Командир Взвода"],
    ["<TAGS >> ","leader","PL_NET"]
] call dzn_fnc_gear_make;

kit_spa_ezapac_ar = [
    ["<EQUIPEMENT       >> ","GEN_Olive_uniform_male","JCA_V_CarrierRigKBT_01_combat_olive_F","CUP_B_Kombat_Olive","JCA_H_HelmetHBK_chops_olive_F","rhsusf_shemagh2_gogg_od"],
    ["<PRIMARY WEAPON   >> ","CUP_lmg_minimi_railed","CUP_200Rnd_TE4_Red_Tracer_556x45_M249",["","","CUP_optic_Elcan_SpecterDR_KF_RMR_od",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","CUP_hgun_Glock17_blk","CUP_17Rnd_9x19_glock17",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["rhs_mag_m67",2],["rhs_mag_an_m8hc",2],["PRIMARY MAG",2],["rhsusf_mag_17Rnd_9x19_FMJ",2]]],
    ["<BACKPACK ITEMS   >> ",[["CUP_200Rnd_TE1_Red_Tracer_556x45_M249_Pouch",3]]],
    ["<DESC >> ","Automatic Rifleman"]
] call dzn_fnc_gear_make;


//Cartel

kit_slave_cartel_random = [
"kit_slave_cartel_r",
"kit_slave_cartel_r",
"kit_slave_cartel_r",
"kit_slave_cartel_r2",
"kit_slave_cartel_r2",
"kit_slave_cartel_r2",
"kit_slave_cartel_sttp",
"kit_slave_cartel_sttp",
"kit_slave_cartel_mm",
"kit_slave_cartel_mm"];

kit_slave_cartel_r = [
    ["<EQUIPEMENT       >> ",PMC_UNIFORMS,"TRYK_V_PlateCarrier_wood_L","","JCA_H_balaclava_01_black_F","rhsusf_oakley_goggles_blk"],
    ["<PRIMARY WEAPON   >> ","sp_fwa_ar10_porto_od","sp_fwa_20Rnd_762_ar10",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["rhs_mag_m67",2],["rhs_mag_an_m8hc",2],["sp_fwa_20Rnd_762_ar10_Ball",10]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Rifleman"]
] call dzn_fnc_gear_make;

kit_slave_cartel_r2 = [
    ["<EQUIPEMENT       >> ",PMC_UNIFORMS,"TRYK_V_PlateCarrier_coyo_L","","TRYK_ESS_CAP","rhsusf_shemagh2_grn"],
    ["<PRIMARY WEAPON   >> ","sp_fwa_653_CAR15","sp_fwa_20Rnd_556_Armalite",["","","sp_fwa_scope_ar_colt3x20",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["rhs_mag_m67",2],["rhs_mag_an_m8hc",2],["PRIMARY MAG",15]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Rifleman"]
] call dzn_fnc_gear_make;

kit_slave_cartel_sttp = [
    ["<EQUIPEMENT       >> ",PMC_UNIFORMS,"TRYK_V_TacVest_coyo","","TRYK_H_PASGT_COYO","rhsusf_shemagh2_grn"],
    ["<PRIMARY WEAPON   >> ","CUP_smg_UZI","CUP_32Rnd_9x19_UZI_M",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["PRIMARY MAG",10]]],
    ["<BACKPACK ITEMS   >> ",[]]
] call dzn_fnc_gear_make;

kit_slave_cartel_mm = [
    ["<EQUIPEMENT       >> ","CUP_I_B_PMC_Unit_15","TRYK_V_TacVest_coyo","","TRYK_r_cap_od_Glasses","rhs_scarf"],
    ["<PRIMARY WEAPON   >> ","CUP_srifle_SVD_wdl","CUP_10Rnd_762x54_SVD_M",["","","CUP_optic_PSO_3_open",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["10Rnd_762x54_Mag",10]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Снайпер"]
] call dzn_fnc_gear_make;

kit_slave_cartel_aux = [
    ["<EQUIPEMENT       >> ","CUP_I_B_PMC_Unit_3","","","",""],
    ["<PRIMARY WEAPON   >> ","","",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","CUP_hgun_Glock17_blk","CUP_17Rnd_9x19_glock17",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ""],
    ["<UNIFORM ITEMS    >> ",[""]],
    ["<VEST ITEMS       >> ",[]],
    ["<BACKPACK ITEMS   >> ",[]]
] call dzn_fnc_gear_make;

//Civil Guard

kit_spa_civguard_fem_r = [
    ["<EQUIPEMENT       >> ","GEN_Feldgrau_uniform","V_TacVest_gen_F","","JCA_H_Beret_01_black_F","JCA_G_balaclava_01_headset_black_F"],
    ["<PRIMARY WEAPON   >> ","CUP_smg_MP5A5","CUP_30Rnd_9x19_MP5",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["PRIMARY MAG",5]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Rifleman"]
] call dzn_fnc_gear_make;

kit_spa_civguard_fem_pistol = [
    ["<EQUIPEMENT       >> ","GEN_Feldgrau_uniform","V_TacVest_gen_F","","H_Watchcap_blk",""],
    ["<PRIMARY WEAPON   >> ","","",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","CUP_hgun_P30L_blk","CUP_17Rnd_9x19_P30L",["","acc_flashlight_pistol","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["HANDGUN MAG",5]]],
    ["<BACKPACK ITEMS   >> ",[]]
] call dzn_fnc_gear_make;

kit_spa_civguard_pistol = [
    ["<EQUIPEMENT       >> ","GEN_Feldgrau_uniform_male","V_TacVest_gen_F","","H_Watchcap_blk",""],
    ["<PRIMARY WEAPON   >> ","","",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","CUP_hgun_P30L_blk","CUP_17Rnd_9x19_P30L",["","acc_flashlight_pistol","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["HANDGUN MAG",5]]],
    ["<BACKPACK ITEMS   >> ",[]]
] call dzn_fnc_gear_make;

kit_spa_civguard_r = [
    ["<EQUIPEMENT       >> ","GEN_Feldgrau_uniform_male","V_TacVest_gen_F","","H_Watchcap_blk",""],
    ["<PRIMARY WEAPON   >> ","CUP_arifle_G36A","CUP_30Rnd_556x45_G36",["","","CUP_optic_G36DualOptics_3D",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> ", ASSIGNED_ITEMS],
    ["<UNIFORM ITEMS    >> ",[UNIFORM_ITEMS]],
    ["<VEST ITEMS       >> ",[["PRIMARY MAG",10]]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Rifleman"]
] call dzn_fnc_gear_make;



//Hostages

kit_civ_doctor = [
    ["<EQUIPEMENT       >> ","CUP_U_C_Labcoat_01","","","",""],
    ["<PRIMARY WEAPON   >> ","","",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> "],
    ["<UNIFORM ITEMS    >> ",[]],
    ["<VEST ITEMS       >> ",[]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Гражданский"]
] call dzn_fnc_gear_make;

kit_civ_paramedic = [
    ["<EQUIPEMENT       >> ","U_C_Paramedic_01_F","","","",""],
    ["<PRIMARY WEAPON   >> ","","",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> "],
    ["<UNIFORM ITEMS    >> ",[]],
    ["<VEST ITEMS       >> ",[]],
    ["<BACKPACK ITEMS   >> ",[]],
    ["<DESC >> ","Гражданский"]
] call dzn_fnc_gear_make;

kit_paramedic_female = [
    ["<EQUIPEMENT       >> ","TCGM_F_Paramedic","","","",""],
    ["<PRIMARY WEAPON   >> ","","",["","","",""]],
    ["<LAUNCHER WEAPON  >> ","","",["","","",""]],
    ["<HANDGUN WEAPON   >> ","","",["","","",""]],
    ["<ASSIGNED ITEMS   >> "],
    ["<UNIFORM ITEMS    >> ",[]],
    ["<VEST ITEMS       >> ",[]],
    ["<BACKPACK ITEMS   >> ",[]]
] call dzn_fnc_gear_make;

//
cargo_vehicle = [
    ["<WEAPONS     >> ",[["CUP_arifle_G36CA3_afg_wdl",2],["CUP_arifle_G36K_RIS_AG36_wdl",2],["KA_UMP9",2],["CUP_lmg_minimi_railed",1],["CUP_smg_BallisticShield_MP7",1]]],
    ["<MAGAZINES   >> ",[["CUP_30Rnd_556x45_G36",20],["rhs_mag_m67",12],["rhs_mag_an_m8hc",12],["KA_30Rnd_9x19_FMJ_Mag",10],["KA_30Rnd_9x19_JHP_Mag",10],["rhs_mag_mk3a2",10],["rhs_mag_mk84",10],["ACE_CTS9",10],["CUP_200Rnd_TE1_Red_Tracer_556x45_M249_Pouch",3],["CUP_200Rnd_TE4_Red_Tracer_556x45_M249",2],["rhsusf_mag_40Rnd_46x30_AP",5],["rhsusf_mag_40Rnd_46x30_FMJ",5],["rhsusf_mag_40Rnd_46x30_JHP",5],["CUP_1Rnd_HE_M203",10],["rhs_mag_m4009",10],["rhs_mag_m576",5],["1Rnd_Smoke_Grenade_shell",3]]],
    ["<ITEMS       >> ",[["ACE_fieldDressing",5],["ACE_packingBandage",5],["ACE_elasticBandage",5],["ACE_tourniquet",5],["ACE_morphine",5],["ACE_epinephrine",5],["ACE_quikclot",5],["ACE_CableTie",5],["ACE_Flashlight_XL50",5],["ACE_EarPlugs",5],["ACE_MapTools",5]]],
    ["<BACKPACKS   >> ",[["TFAR_anprc155",1],["B_AssaultPack_khk",1],["ACE_TacticalLadder_Pack",2]]]
] call dzn_fnc_gear_make;
