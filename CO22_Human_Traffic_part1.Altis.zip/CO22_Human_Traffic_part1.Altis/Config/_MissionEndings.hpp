class CfgDebriefing
{
	class WIN
	{
		title = "Миссия выполнена";
		subtitle = "Восхитительный успех!";
		description = "Задача выполнена.";
	};
	class WIPED
	{
		title = "Миссия провалена";
		subtitle = "Все погибли";
		description = "Такие дела...";
	};
};