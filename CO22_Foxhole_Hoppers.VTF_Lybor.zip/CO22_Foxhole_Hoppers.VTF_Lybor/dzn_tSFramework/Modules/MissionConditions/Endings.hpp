class CfgDebriefing
{
	class WIN
	{
		title = "Миссия выполнена";
		subtitle = "Восхитительный успех!";
		description = "Задача выполнена.";
	};
	class FAIL
	{
		title = "Миссия провалена";
		subtitle = "Восхитительный провал";
		description = "";
	};
	class WIPED
	{
		title = "Миссия провалена";
		subtitle = "Все погибли";
		description = "Такие дела...";
	};
};