
#define RESPAWN_MSG_SCHEDULED <t color=COLOR_HEX_GOLD>Возрождение</t>
#define RESPAWN_MSG_UNSCHEDULED <t color=COLOR_HEX_GOLD>Возрождение отменено</t>
#define RESPAWN_HINT_MSG_TEXT <t align='center'>%1</t>