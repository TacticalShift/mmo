class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Шуфутинский спасён, а его похитителей ждут костры рябин";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
