#include "..\..\script_macro.hpp"

#define COMPONENT core

#define LEGACY_MODULES \
    "Briefing", \
    "CCP", \
    "FARP", \
    "ArtillerySupport", \
    "Interactives", \
    "ACEActions", \
    "EditorUnitBehavior", \
    "EditorRadioSettings", \
    "tSAdminTools", \
    "Conversations"
