
#define CREW_OPTIONS_HINT_MEMBER_ADDED Добавлен новый член экипажа на место <t color=COLOR_HEX_AQUA>%1</t>! 
#define CREW_OPTIONS_HINT_MEMBER_REMOVED Место <t color=COLOR_HEX_AQUA>%1</t> освобождено! 

#define CREW_OPTIONS_HINT_LIGHTS \
    <t size=UI_FONT_SIZE_L color=COLOR_HEX_AQUA>Изменен режим бортовых огней</t><br/>\
    <t align=left color=COLOR_HEX_GRAY>Габариты</t><t align=right>%1</t><br/>\
    <t align=left color=COLOR_HEX_GRAY>Фары</t><t align=right>%2</t>

#define CREW_OPTIONS_HINT_OCCUPIED Место %1 уже занято!

#define CREW_OPTIONS_HINT_OCCUPIED_BY_PLAYER Место %1 занято игроком!
#define CREW_OPTIONS_HINT_IS_EMPTY_SEAT Место %1 пустое!
#define CREW_OPTIONS_HINT_ALL_SEATS_CLEARED Все AI-юниты в машине были удалены!