class CfgDebriefing
{  
    class WIN
    {
        title = "Все обжективы зачищены";
        subtitle = "Успех!";
        description = "Задание выполнено";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
	class WIN2
    {
        title = "Обжектив браво зачищен";
        subtitle = "Успех!";
        description = "Задание выполнено";
    };            
	class WIN3
    {
        title = "Обжектив альфа зачищен";
        subtitle = "Успех!";
        description = "Задание выполнено";
    };    
};
