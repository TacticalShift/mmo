class CfgDebriefing
{  
    class WIN
    {
        title = "Все обжективы зачищены";
        subtitle = "Успех!";
        description = "Задание выполнено";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};