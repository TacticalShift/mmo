class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Мы захватили город и наши силы смогут продвигаться далее";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Мы не справились со своей задачи....";
    };
};
