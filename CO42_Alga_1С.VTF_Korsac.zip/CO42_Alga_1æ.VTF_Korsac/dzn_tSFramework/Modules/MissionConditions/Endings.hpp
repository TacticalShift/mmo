class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };                  
	    class MINORWIN
    {
        title = "Задание частично выполнено";
        subtitle = "Частичный успех!";
        description = "Мы не смогли захватить зону Владимир, но заняли плацдарм для новой атаки";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
