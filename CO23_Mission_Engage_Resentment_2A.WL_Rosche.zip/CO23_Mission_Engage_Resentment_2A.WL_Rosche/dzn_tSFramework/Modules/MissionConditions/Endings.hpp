class CfgDebriefing
{  
	class WIN
	{
		title = "Миссия выполнена";
		subtitle = "Восхитительный успех!";
		description = "Все задачи выполнены! Наше наступление успешно развивается!";
	};
	class MAIN_WIN
	{
		title = "Миссия выполнена";
		subtitle = "Успех!";
		description = "Основные задачи выполнены. Скоро наши части перейдут в атаку.";
	};          
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
