#include "..\..\script_macro.hpp"

#define COMPONENT POM

#define MAP_CTRL (findDisplay 12 displayCtrl 51)

#define SUBTOPIC_NAME "Добавить маркеры"
