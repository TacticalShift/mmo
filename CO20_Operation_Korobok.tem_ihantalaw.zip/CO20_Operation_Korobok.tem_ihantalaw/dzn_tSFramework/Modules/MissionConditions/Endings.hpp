class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
	class WIN2
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Смогли захватить только OBJ ANTON, молодцы";
    };                  
};
