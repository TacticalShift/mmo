#include "..\..\script_macro.hpp"

#define COMPONENT AirborneSupport

#define MRK_ICON_AIR "\A3\ui_f\data\map\markers\nato\n_air.paa"
#define MRK_ICON_SIZE 32
