#include "..\script_macro.hpp"

#define COMPONENT EditorVehicleCrew

#define EVC_GAMELOGIC_FLAG Q(tSF_EVC)

#define DZN_DYNAI_VEHICLE_HOLD "vehicle hold"
#define DZN_DYNAI_VEHICLE_HOLD_45 "vehicle 45 hold"
#define DZN_DYNAI_VEHICLE_HOLD_90 "vehicle 90 hold"
