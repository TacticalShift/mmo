#include "..\defines.h"

#define DBG_PREFIX "(dzn_gear.Editor.AmmoBearer) "

#define ThisCOB ECOB(Editor,AmmoBearer)
#define COMPONENT_PATH dzn_gear\plugins\Editor\AmmoBearer

