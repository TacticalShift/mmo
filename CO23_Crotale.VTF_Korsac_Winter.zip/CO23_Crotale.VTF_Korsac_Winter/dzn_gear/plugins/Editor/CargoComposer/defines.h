#include "..\defines.h"

#define DBG_PREFIX "(dzn_gear.Editor.CargoComposer) "

#define ThisCOB ECOB(Editor,CargoComposer)
#define COMPONENT_PATH dzn_gear\plugins\Editor\CargoComposer

