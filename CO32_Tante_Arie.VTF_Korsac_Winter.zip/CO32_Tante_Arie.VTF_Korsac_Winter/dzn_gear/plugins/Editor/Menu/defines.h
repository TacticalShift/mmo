#include "..\defines.h"

#define DBG_PREFIX "(dzn_gear.Editor.Menu) "

#define ThisCOB ECOB(Editor,Menu)
#define COMPONENT_PATH dzn_gear\plugins\Editor\Menu
