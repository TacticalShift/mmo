#include "..\defines.h"

#define DBG_PREFIX "(dzn_gear.Editor.Core) "

#define ThisCOB dzn_gear_Editor_CoreComponent

#define COMPONENT_PATH dzn_gear\plugins\Editor\Core

#define NEWLINE_AND_TAB toString[10,32,32,32,32]
#define NEWLINE toString[10]

#define COLOR_POOL selectRandom ["F","C","B","3","6","9"]

#define WIPE_ALL 0
#define WIPE_CONTAINERS 1
#define WIPE_BACKPACK 2