class CfgDebriefing
{  
    class FULL_WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задачи выполнены";
    };
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };
    class FAIL_OPT
    {
        title = "Задание выполнено частично";
        subtitle = "Успех?";
        description = "Мы захватили одну из позиций";
    }; 
    class FAIL
    {
        title = "Задание выполнено";
        subtitle = "Провал!";
        description = "Задачи не выполнены";
    };                       
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
