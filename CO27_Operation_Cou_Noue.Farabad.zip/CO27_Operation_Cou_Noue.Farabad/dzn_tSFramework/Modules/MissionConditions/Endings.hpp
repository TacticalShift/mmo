class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Обе цели захвачены, Vive la France!";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли или отсутпили!";
        description = "Готовьтесь к мемам про белый флаг..";
    };
};
