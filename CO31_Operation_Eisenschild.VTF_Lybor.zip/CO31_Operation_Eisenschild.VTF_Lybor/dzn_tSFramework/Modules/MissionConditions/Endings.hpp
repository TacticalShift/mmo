class CfgDebriefing
{  
    class WIN
    {
        title = "Aufgabe abgeschlossen";
        subtitle = "Erfolg!";
        description = "Hurra, wir konnten den Deal zerstören!";
    };                  
    class WIPED
    {
        title = "Aufgabe fehlgeschlagen";
        subtitle = "Einbruch";
        description = "Oh nein, wir konnten den Deal nicht aufhalten und viele Menschen starben.";
    };
};
