# {CO25_AngelSlayer_1A.takistan}
ISIS forces attack US airfield base

<img src='{https://i.imgur.com/rjJ2qCA.jpeg}' />

### Version: {1A}

### Changelog: {Перечень изменений/отличий от предыдущей версии}
...

    # NOT APPROVED
    | Reviewer | Result |
    | ------------ | ------------- |
    | - | - |
    | - | - |
