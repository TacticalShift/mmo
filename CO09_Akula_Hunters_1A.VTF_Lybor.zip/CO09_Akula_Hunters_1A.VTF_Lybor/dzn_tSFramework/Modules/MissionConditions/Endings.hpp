class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Мы смогли уничтожить вертолет";
    }; 
    class FAIL
    {
        title = "Задание провалено";
        subtitle = "Неудача!";
        description = "Вертолет смог уйти от нас";
    };                  	
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
