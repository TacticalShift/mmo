class CfgDebriefing
{  
    class TOTAL_WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };    
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    };                  
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
