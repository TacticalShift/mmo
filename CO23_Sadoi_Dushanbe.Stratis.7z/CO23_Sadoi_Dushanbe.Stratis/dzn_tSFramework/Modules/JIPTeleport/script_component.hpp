#include "..\script_macro.hpp"

#define COMPONENT JIPTeleport

#define ACTION_TITLE "<t size='1.25' color='#EDB81A'>JIP Teleport</t>"

#define HINT_TEMPLATE "<t color='#EDB81A' size='1.5'>JIP Teleport</t><br/><br/><t>%1</t>"
#define POSITION_RELATIVE_TO_LEADER [7,0,0]
