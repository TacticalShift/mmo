#include "ui.hpp"

#define TSF_VERSION_NUMBER "v2.14"

#define TSF_KEYBIND_SECTION "Tactical Shift Framework"

// Common macro
#define MISSION_STARTED time > 0
#define ON_MISSION_STARTED time > 0

// Dynai
#define DZN_DYNAI_RUNNING (!isNil "dzn_dynai_initialized")
#define DZN_DYNAI_RUNNING_SERVER_SIDE (!isNil "dzn_dynai_initialized" && {dzn_dynai_initialized})

// dzn_Gear
#define DZN_GEAR_RUNNING (!isNil "dzn_gear_serverInitDone")
#define DZN_GEAR_APPLIED(UNIT) (UNIT getVariable ["dzn_gear_done", false])

// Client/Server execution
#define __SERVER_ONLY__ if (!isServer) exitWith {};
#define __CLIENT_ONLY__ if (!hasInterface) exitWith {};
#define __HEADLESS_OR_SERVER__ if ( \
        isMultiplayer && { \
            (isNil "HC" && !isServer) || \
            (!isNil "HC" && (hasInterface || isServer)) \
        } \
    ) exitWith {};
#define __NOT_HEADLESS__ if (!hasInterface && !isServer) exitWith {};

// Modules availability
#define TSF_MODULE_ENABLED(MODULE) ECOB(Core) call [F(isModuleEnabled), Q(MODULE)]
#define TSF_COMPONENT(NAME) ECOB(Core) call [F(getComponent), NAME]

// tSF Error reporting
#define TSF_ERROR_METHOD F(reportError)
#define TSF_ERROR(REASON,MSG) ECOB(Core) call [TSF_ERROR_METHOD, [Q(COMPONENT),REASON,MSG]]
#define TSF_ERROR_1(REASON,MSG,ARG1) ECOB(Core) call [TSF_ERROR_METHOD, [Q(COMPONENT),REASON,FORMAT_1(MSG,ARG1)]]
#define TSF_ERROR_2(REASON,MSG,ARG1,ARG2) ECOB(Core) call [TSF_ERROR_METHOD, [Q(COMPONENT),REASON,FORMAT_2(MSG,ARG1,ARG2)]]
#define TSF_ERROR_3(REASON,MSG,ARG1,ARG2,ARG3) ECOB(Core) call [TSF_ERROR_METHOD, [Q(COMPONENT),REASON,FORMAT_3(MSG,ARG1,ARG2,ARG3)]]
#define TSF_ERROR_4(REASON,MSG,ARG1,ARG2,ARG3,ARG4) ECOB(Core) call [TSF_ERROR_METHOD, [Q(COMPONENT),REASON,FORMAT_4(MSG,ARG1,ARG2,ARG3,ARG4)]]
#define TSF_ERROR_5(REASON,MSG,ARG1,ARG2,ARG3,ARG4,ARG5) ECOB(Core) call [TSF_ERROR_METHOD, [Q(COMPONENT),REASON,FORMAT_5(MSG,ARG1,ARG2,ARG3,ARG4,ARG5)]]

#define TSF_ERROR_TYPE__NO_CONFIG "Конфиг не найден"
#define TSF_ERROR_TYPE__NO_MARKER "Маркер не найден"
#define TSF_ERROR_TYPE__MISCONFIGURED "Некорректная конфигурация"
#define TSF_ERROR_TYPE__MISSING_ENTITY "Отстутсвует целевой объект"
#define TSF_ERROR_TYPE__SETTINGS_PARSE_ERROR "Не удалось распарсить файл настроек (Settings.yaml)"
#define TSF_ERROR_TYPE__INVALID_ARG "Аргумент не корректен"
#define TSF_ERROR_TYPE__MISSING_KIT "Набор снаряжения не найден"
#define TSF_ERROR_TYPE__MISSING_ITEM "Неполное снаряжение"

// -- Events
#define TSF_EVENT_COMPONENT_STATE_CHANGED Q(tSF_Event_ComponentStateChanged)



// Credits: CBA Team (https://github.com/CBATeam/CBA_A3/blob/master/addons/main/script_macros_common.hpp)
//#define DEBUG true

#define MAINPREFIX dzn_tSFramework
#define SUBPREFIX Modules
#define PREFIX tSF
#ifndef COMPONENT
    #define COMPONENT common
#endif

#define DOUBLES(var1,var2) var1##_##var2
#define TRIPLES(var1,var2,var3) var1##_##var2##_##var3
#define QUOTE(var1) #var1

#define MODULE_COMPONENT DOUBLES(PREFIX,COMPONENT)

#define GVAR(var1) DOUBLES(MODULE_COMPONENT,var1)
#define EGVAR(var1,var2) TRIPLES(PREFIX,var1,var2)
#define QGVAR(var1) QUOTE(GVAR(var1))
#define QEGVAR(var1,var2) QUOTE(EGVAR(var1,var2))
#define QQGVAR(var1) QUOTE(QGVAR(var1))
#define QQEGVAR(var1,var2) QUOTE(QEGVAR(var1,var2))

#define FUNC(var1) TRIPLES(MODULE_COMPONENT,fnc,var1)
#define FUNCMAIN(var1) TRIPLES(PREFIX,fnc,var1)
#define FUNC_INNER(var1,var2) TRIPLES(DOUBLES(PREFIX,var1),fnc,var2)
#define EFUNC(var1,var2) FUNC_INNER(var1,var2)
#define QFUNC(var1) QUOTE(FUNC(var1))
#define QFUNCMAIN(var1) QUOTE(FUNCMAIN(var1))
#define QFUNC_INNER(var1,var2) QUOTE(FUNC_INNER(var1,var2))
#define QEFUNC(var1,var2) QUOTE(EFUNC(var1,var2))
#define QQFUNC(var1) QUOTE(QFUNC(var1))
#define QQFUNCMAIN(var1) QUOTE(QFUNCMAIN(var1))
#define QQFUNC_INNER(var1,var2) QUOTE(QFUNC_INNER(var1,var2))
#define QQEFUNC(var1,var2) QUOTE(QEFUNC(var1,var2))


#define AIO_CONFIG_DIR Config
// -- Module and file execution
#define COMPONENT_PATH(FILE) MAINPREFIX\SUBPREFIX\COMPONENT\FILE
#define COMPONENT_SUBPATH(SUBPATH,FILE) MAINPREFIX\SUBPREFIX\COMPONENT\SUBPATH\FILE
#define COMPONENT_SETTINGS_SQF_PATH AIO_CONFIG_DIR\COMPONENT

#define COMPILE_EXECUTE(PATH) call compileScript ['PATH.sqf']

#define INIT_SETTING COMPILE_EXECUTE(COMPONENT_SETTINGS_SQF_PATH)
#define INIT_FUNCTIONS COMPILE_EXECUTE(COMPONENT_PATH(Functions))
#define INIT_FILE(FILE) COMPILE_EXECUTE(COMPONENT_PATH(FILE))
#define INIT_FILE_SUBDIR(DIR,FILE) COMPILE_EXECUTE(COMPONENT_SUBPATH(DIR,FILE))
#define INIT_COMMON COMPILE_EXECUTE(COMPONENT_PATH(Init))
#define INIT_SERVER if (isServer) then { COMPILE_EXECUTE(COMPONENT_PATH(InitServer)) }
#define INIT_CLIENT if (hasInterface) then { COMPILE_EXECUTE(COMPONENT_PATH(InitClient)) }

#define INIT_COMPONENT COMPILE_EXECUTE(COMPONENT_PATH(Component))


// Public functions in component
#define COMPONENT_PUBLIC_FNC_PATH(FILE) MAINPREFIX\SUBPREFIX\COMPONENT\Public\fnc_##FILE##.sqf
#define PREP_PUBLIC_FUNCTION(NAME) FUNC(NAME) = compileScript [QUOTE(COMPONENT_PUBLIC_FNC_PATH(NAME))]


// --- Component Object
#define COB DOUBLES(MODULE_COMPONENT,Component)
#define ECOB(var1) TRIPLES(PREFIX,var1,Component)
#define QCOB Q(COB)
#define QECOB(var1) Q(ECOB(var1))

#define Q(X) #X
#define F_WRAP(NAME) fnc_##NAME
#define F(NAME) Q(F_WRAP(NAME))

#define COMPONENT_STATUS_VARNAME "#status"
#define COMPONENT_STATUS_STARTING "STARTING"
#define COMPONENT_STATUS_OK "OK"
#define COMPONENT_STATUS_FAILED "FAILED"

#define COMPONENT_TYPE \
   ["#type", format ["tSF_%1_Component", Q(COMPONENT)]],\
   ["#str", {format ["tSF_%1_Component", Q(COMPONENT)]}],\
   [COMPONENT_STATUS_VARNAME, COMPONENT_STATUS_STARTING]
#define COMPONENT_FNC_PATH(FILE) MAINPREFIX\SUBPREFIX\COMPONENT\fnc_##FILE##.sqf
#define PREP_COMPONENT_FUNCTION(NAME) \
    [F(NAME), compileScript [Q(COMPONENT_FNC_PATH(NAME))]]

#define COMPONENT_SETTINGS_PATH AIO_CONFIG_DIR\COMPONENT##.yaml
#define PREP_COMPONENT_SETTINGS \
    [Q(Settings), [Q(COMPONENT_SETTINGS_PATH)] call dzn_fnc_parseSFML]

#define REGISTER_COMPONENT ECOB(Core) call [F(registerComponent), [Q(COMPONENT), COB]]
#define CREATE_AND_REGISTER_COMPONENT(DECLARATION) \
    createHashMapObject [DECLARATION]; \
    REGISTER_COMPONENT


#define SET_COMPONENT_STATUS_OK(CMP) \
    CMP set [COMPONENT_STATUS_VARNAME, COMPONENT_STATUS_OK]; \
    LOG("Component initialization status => OK");\
    [TSF_EVENT_COMPONENT_STATE_CHANGED] call CBA_fnc_localEvent
#define SET_COMPONENT_STATUS_FAILED(CMP) \
    CMP set [COMPONENT_STATUS_VARNAME, COMPONENT_STATUS_FAILED]; \
    LOG("Component initialization  status => FAILED");\
    [TSF_EVENT_COMPONENT_STATE_CHANGED] call CBA_fnc_localEvent

// --- Component Objects - Setting gettersв
#define SETTING(SRC,NODE1) (SRC get Q(Settings) get Q(NODE1))
#define SETTING_2(SRC,NODE1,NODE2) (SRC get Q(Settings) get Q(NODE1) get Q(NODE2))
#define SETTING_3(SRC,NODE1,NODE2,NODE3) (SRC get Q(Settings) get Q(NODE1) get Q(NODE2) get Q(NODE3))

#define SETTING_OR_DEFAULT(SRC,NODE1,DEFAULT) (SRC get Q(Settings) getOrDefault [Q(NODE1), DEFAULT])
#define SETTING_OR_DEFAULT_2(SRC,NODE1,NODE2,DEFAULT) (SRC get Q(Settings) get Q(NODE1) getOrDefault [Q(NODE2), DEFAULT])
#define SETTING_OR_DEFAULT_3(SRC,NODE1,NODE2,NODE3,DEFAULT) (SRC get Q(Settings) get Q(NODE1) get Q(NODE2) getOrDefault [Q(NODE3), DEFAULT])

#define __EXIT_ON_SETTINGS_PARSE_ERROR__ \
    if (SETTING(_self,#ERRORS) isNotEqualTo []) exitWith { \
        ((SETTING(_self,#ERRORS)) select 0) params ["","_lineNo","","_errorText"]; \
        private _src = SETTING(_self,#SOURCE); \
        TSF_ERROR_3(TSF_ERROR_TYPE__SETTINGS_PARSE_ERROR,"Модуль не запущен! Ошибка '%1' в строке %2 файла %3",_errorText,_lineNo,_src); \
        SET_COMPONENT_STATUS_FAILED(_self); \
    };


// --- Module init
// #define RUN_MODULE(X) [] call compileScript ['MAINPREFIX\SUBPREFIX\X\data\PreInit.sqf'];

// --- Useful macro
#define STARTS_WITH(STR,SUBSTR) (STR select [0, count SUBSTR] == SUBSTR)

// -- Logging
#define LOG_SYS_FORMAT(LEVEL,MESSAGE) format ['[%1] (%2.%3): %4: %5', 'PREFIX', 'COMPONENT', __FILE_SHORT__, LEVEL, MESSAGE]
#define LOG_SYS(LEVEL,MESSAGE) diag_log text LOG_SYS_FORMAT(LEVEL,MESSAGE)
#define LOG(MESSAGE) LOG_SYS('LOG',MESSAGE)
#define LOG_1(MESSAGE,ARG1) LOG(FORMAT_1(MESSAGE,ARG1))
#define LOG_2(MESSAGE,ARG1,ARG2) LOG(FORMAT_2(MESSAGE,ARG1,ARG2))
#define LOG_3(MESSAGE,ARG1,ARG2,ARG3) LOG(FORMAT_3(MESSAGE,ARG1,ARG2,ARG3))
#define LOG_4(MESSAGE,ARG1,ARG2,ARG3,ARG4) LOG(FORMAT_4(MESSAGE,ARG1,ARG2,ARG3,ARG4))
#define LOG_5(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5) LOG(FORMAT_5(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5))
#define LOG_6(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6) LOG(FORMAT_6(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6))
#define LOG_7(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7) LOG(FORMAT_7(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7))
#define LOG_8(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7,ARG8) LOG(FORMAT_8(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7,ARG8))

#ifdef DEBUG
	#define DEBUG_MSG(MESSAGE) LOG_SYS("DEBUG",MESSAGE)
	#define DEBUG_1(MESSAGE,ARG1) DEBUG_MSG(FORMAT_1(MESSAGE,ARG1))
	#define DEBUG_2(MESSAGE,ARG1,ARG2) DEBUG_MSG(FORMAT_2(MESSAGE,ARG1,ARG2))
	#define DEBUG_3(MESSAGE,ARG1,ARG2,ARG3) DEBUG_MSG(FORMAT_3(MESSAGE,ARG1,ARG2,ARG3))
	#define DEBUG_4(MESSAGE,ARG1,ARG2,ARG3,ARG4) DEBUG_MSG(FORMAT_4(MESSAGE,ARG1,ARG2,ARG3,ARG4))
	#define DEBUG_5(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5) DEBUG_MSG(FORMAT_5(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5))
	#define DEBUG_6(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6) DEBUG_MSG(FORMAT_6(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6))
	#define DEBUG_7(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7) DEBUG_MSG(FORMAT_7(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7))
	#define DEBUG_8(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7,ARG8) DEBUG_MSG(FORMAT_8(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7,ARG8))
#else
    #define DEBUG_MSG
    #define DEBUG_1(MSG)
    #define DEBUG_2(MSG,ARG1)
    #define DEBUG_3(MSG,ARG1,ARG2)
    #define DEBUG_4(MSG,ARG1,ARG2,ARG3)
    #define DEBUG_5(MSG,ARG1,ARG2,ARG3,ARG4)
	#define DEBUG_5(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5)
	#define DEBUG_6(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6)
	#define DEBUG_7(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7)
	#define DEBUG_8(MESSAGE,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7,ARG8)
#endif

#define FORMAT_1(STR,ARG1) format[STR, ARG1]
#define FORMAT_2(STR,ARG1,ARG2) format[STR, ARG1, ARG2]
#define FORMAT_3(STR,ARG1,ARG2,ARG3) format[STR, ARG1, ARG2, ARG3]
#define FORMAT_4(STR,ARG1,ARG2,ARG3,ARG4) format[STR, ARG1, ARG2, ARG3, ARG4]
#define FORMAT_5(STR,ARG1,ARG2,ARG3,ARG4,ARG5) format[STR, ARG1, ARG2, ARG3, ARG4, ARG5]
#define FORMAT_6(STR,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6) format[STR, ARG1, ARG2, ARG3, ARG4, ARG5, ARG6]
#define FORMAT_7(STR,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7) format[STR, ARG1, ARG2, ARG3, ARG4, ARG5, ARG6, ARG7]
#define FORMAT_8(STR,ARG1,ARG2,ARG3,ARG4,ARG5,ARG6,ARG7,ARG8) format[STR, ARG1, ARG2, ARG3, ARG4, ARG5, ARG6, ARG7, ARG8]
