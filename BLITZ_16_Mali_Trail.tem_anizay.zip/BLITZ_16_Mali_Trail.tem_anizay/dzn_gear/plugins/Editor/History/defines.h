#include "..\defines.h"

#define DBG_PREFIX "(dzn_gear.Editor.History) "

#define ThisCOB ECOB(Editor,History)
#define COMPONENT_PATH dzn_gear\plugins\Editor\History

