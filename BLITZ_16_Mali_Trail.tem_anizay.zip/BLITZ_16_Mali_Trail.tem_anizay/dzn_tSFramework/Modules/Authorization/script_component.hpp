#include "..\script_macro.hpp"

#define COMPONENT Authorization

#define ROLE [
#define HAS ,
#define PERMISSIONS ]

#define AUTHORIZATION_TYPES ["ARTILLERY", "AIRBORNE", "POM"]