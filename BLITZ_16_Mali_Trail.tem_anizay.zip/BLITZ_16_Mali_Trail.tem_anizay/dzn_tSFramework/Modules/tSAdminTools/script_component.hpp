#include "..\script_macro.hpp"
#include "messages.hpp"

#define COMPONENT tSAdminTools

#define LOG_PREFIX "(tSAdminTools) "
#define DBG_ diag_log parseText format [LOG_PREFIX +
#define EOL ]
