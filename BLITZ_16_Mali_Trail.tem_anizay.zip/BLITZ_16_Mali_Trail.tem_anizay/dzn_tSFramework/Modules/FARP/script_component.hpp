#define DEBUG true

#include "..\script_macro.hpp"
#include "messages.hpp"

#define COMPONENT FARP

#define FARP_NAME "FARP"
#define OBJECT_INTERACTIBLE_FLAG Q(tSF_FARP_Interactable)

#define GAMELOGIC_IS_FARP_FLAG Q(tSF_FARP)
#define GAMELOGIC_FARP_NAME Q(tSF_FARP_Name)
#define GAMELOGIC_CONFIG_ID Q(tSF_FARP_Config)
#define GAMELOGIC_COMPOSITION Q(tSF_FARP_Composition)
#define GAMELOGIC_CLASSES Q(tSF_FARP_SupplyVehicles)

#define GAMELOGIC_RESOURCES Q(tSF_FARP_Resources)

#define VEHICLE_FLAG Q(tSF_FARP_ServiceDetails)



#define RESPAWN_TIME_DISABLED 999999
