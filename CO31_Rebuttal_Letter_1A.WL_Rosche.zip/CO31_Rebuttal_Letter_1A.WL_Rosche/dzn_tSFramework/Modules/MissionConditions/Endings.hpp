class CfgDebriefing
{  
    class WIN
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Задача выполнена";
    }; 
    class FAIL
    {
        title = "Задание провалено";
        subtitle = "Задача не выполнена в предназначенное время";
        description = "Задача не выполнена";
    };      	
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
