class CfgDebriefing
{
	class WIN
	{
		title = "Миссия выполнена";
		subtitle = "Восхитительный успех!";
		description = "Задача выполнена.";
	};
		class FAIL
	{
		title = "Миссия провалена";
		subtitle = "Задача не выполнена в срок";
		description = "Такие дела...";
	};
	class WIPED
	{
		title = "Миссия провалена";
		subtitle = "Все погибли";
		description = "Такие дела...";
	};
};