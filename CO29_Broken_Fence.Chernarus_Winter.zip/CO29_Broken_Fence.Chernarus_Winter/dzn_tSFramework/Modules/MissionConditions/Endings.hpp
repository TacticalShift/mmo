class CfgDebriefing
{  
    class WIN_1
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Обе деревни зачищены, южный фланг для Зеленогрска обезопасен";
    };
    class WIN_2
    {
        title = "Задание выполнено";
        subtitle = "Успех!";
        description = "Каменка зачищено, теперь противник не сможет перебрасывать подкрепление через наше КПП";
    }; 	
    class WIPED
    {
        title = "Задание провалено";
        subtitle = "Все погибли!";
        description = "Такие дела...";
    };
};
